
import React from "react";
import { useRouter } from "next/router";
import { Box } from "@mui/system";
import PlaceIcon from '@mui/icons-material/Place';
import Image from "next/image";
import ComboBox from "../../../components/address/addressAuto";
import { Maap } from "../../../components/map/map";
import { Button, Grid, Typography } from "@mui/material";
import { LocationCtx, LocationProvider } from "../../../context/location-context";


export default function Location() {
   

    const [lat, setLat] = React.useState<string>('')
    const [lng, setLng] = React.useState<string>('')
    const [location, setLocation] = React.useState(0)
    const [img, setImg] = React.useState("");
    const router = useRouter();

    const handleBack = () => {
        if (router.query.itemId) {
            router.push("/become-a-host/" + router.query.itemId + "/privacy-type")
        }
    }
    const { itemId } = router.query;

    const BackHandle = () => {
        router.push("/become-a-host/" + itemId + "/privacy-type")
    }

    const handleLatLng = (lat:string, lng:string) => {
        setLat(lat);
        setLng(lng);
    }


    const handleNext = ()=>{
        //여기서 업데이트를 한번 더 시키긴 해야 함.
        router.push("/become-a-host/" + router.query.itemId + "/floor-plan")
    }

    //4단계
    return (
<LocationProvider>
        <Grid component={"main"} container  >

            <Grid item sx={{ display: "flex", flex: 1, bgcolor: "black", color: "white", height: '100vh', alignItems: "center", justifyContent: "center" }}
            >
                <Typography component="h1" variant="h5" textAlign={"center"}>
                    숙소 위치는 어디인가요?
                </Typography>
            </Grid>



            <Grid item sx={{ display: "flex", flex: 1, flexDirection: "column", height: '100vh', justifyContent: "center" }}>

                <Box sx={{ display: "flex", flex: 1, flexDirection: "column", position: 'relative' }}>

                    <Box>
                        <Maap lat={lat} lng={lng} />
                    </Box>

                    <Box sx={{ left: '35%', top: 200, position: 'absolute' }}>
                        <ComboBox onLatLng={handleLatLng}/>
                    </Box>

                    <Box sx={{ position: 'absolute', bottom: 0, left: 50 }}>

                        <Button variant="contained" sx={[{ width: 10, mt: 5, mb: 5, bgcolor: 'black' }, { '&:hover': { 'backgroundColor': '#333' } }]} onClick={BackHandle}>뒤로</Button>

                    </Box>
                    <Box sx={{ position: 'absolute', bottom: 0, left: 450 }}>

                        <Button variant="contained" sx={[{ width: 10, mt: 5, mb: 5, bgcolor: 'black' }, { '&:hover': { 'backgroundColor': '#333' } }]} onClick={handleNext}>다음</Button>

                    </Box>
                </Box>

            </Grid>
        </Grid>
        </LocationProvider>
    );
}