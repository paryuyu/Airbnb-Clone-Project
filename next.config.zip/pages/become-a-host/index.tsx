import { Button, Grid, Typography, useForkRef } from "@mui/material";
import { Box } from "@mui/system";
import HomeIcon from '@mui/icons-material/Home';
import KeyboardArrowRightIcon from '@mui/icons-material/KeyboardArrowRight';
import AddIcon from '@mui/icons-material/Add';
import { useRouter } from "next/router";
import React from "react";
import { useSession } from "next-auth/react";
import Link from "next/link";
import { AccomodationData } from "../../lib/model/accomodation";
export default function BecomeAHostPropertyTypeGroup() {

    const { data, status } = useSession();
    const [rstdata, setrstdata] = React.useState<AccomodationData[]>();
    const router = useRouter();

    const handleNew = () => {
        router.push("/become-a-host/property-type-group");
    }

    async function IncompleteData() {
        let find = await fetch("/api/accomodation/roomtypefind")
        let rst = await find.json();
        if (rst.data.length > 0) {
            setrstdata(rst.data);
        }
    }

    React.useEffect(() => {
        if (data && status === "authenticated") {
            IncompleteData()
        }
    }, [status])

    async function findIdData(id: string) {
        let find = await fetch("/api/accomodation/roomIdFind", {
            method: "post",
            body: JSON.stringify({ _id: id }),
            headers: { "Content-type": "application/json" }
        })

        let rst = await find.json();

        if (rst.result) {
            let arr = Object.keys(rst.data);
            let first = arr.find(one => one === "groupType");
            let second = arr.find(one => one === "propertyType");
            let third = arr.find(one => one === "privacyType");
            let four = arr.find(one => one === "location");
            let five = arr.find(one => one === "floorPlan");
            let six = arr.find(one => one === "amenities");
            let seven = arr.find(one => one === "Photos");
            let eight = arr.find(one => one === "title");
            if (first == "groupType" && second == undefined && third == undefined && four == undefined && five == undefined && six == undefined && seven == undefined && eight == undefined) {
                router.push("/become-a-host/" + id + "/property-type");

            } else if (first == "groupType" && second == "propertyType" && third == undefined && four == undefined && five == undefined && six == undefined && seven == undefined && eight == undefined) {
                router.push("/become-a-host/" + id + "/privacy-type");

            } else if (first == "groupType" && second == "propertyType" && third == "privacyType" && four == undefined && five == undefined && six == undefined && seven == undefined && eight == undefined) {
                router.push("/become-a-host/" + id + "/location");

            } else if (first == "groupType" && second == "propertyType" && third == "privacyType" && four == 'location' && five == undefined&& six == undefined && seven == undefined && eight == undefined) {
                router.push("/become-a-host/" + id + "/floor-plan");
                
            } else if (first == "groupType" && second == "propertyType" && third == "privacyType" && four == 'location' && five == 'floorPlan' && six == undefined && seven == undefined && eight == undefined) {
                router.push("/become-a-host/" + id + "/amenities");
            } else if (first == "groupType" && second == "propertyType" && third == "privacyType" && four == 'location' && five == 'floorPlan' && six == 'amenities' && seven == undefined && eight == undefined) {
                router.push("/become-a-host/" + id + "/photos");
            }else if (first == "groupType" && second == "propertyType" && third == "privacyType" && four == 'location' && five == 'floorPlan' && six == 'amenities'&& seven == 'Photos'  && eight == undefined) {
                router.push("/become-a-host/" + id + "/title");
            }else if (first == "groupType" && second == "propertyType" && third == "privacyType" && four == 'location' && five == 'floorPlan' && six == 'amenities'&& seven == 'Photos'&& seven == 'Photos'&& eight == 'title') {
                router.push("/become-a-host/" + id + "/description");
            }
        }

    }

    const handleclick = async (id: string) => {
        await findIdData(id)
    }

    return (
        <Grid component={"main"} container  >

            <Grid item sx={{ display: "flex", flex: 1, bgcolor: "black", color: "white", height: '100vh', alignItems: "center", justifyContent: "center" }}
            >
                <Typography component="h1" variant="h5" textAlign={"center"}>
                    호스팅 할 숙소 유형을 알려주세요
                </Typography>
            </Grid>

            <Grid item sx={{ display: "flex", flex: 1, flexDirection: "column", height: '100vh', pr: 10, pl: 10 }}>

                {rstdata &&
                    <Typography fontSize={20} fontWeight={"bold"} pl={2} mt={4}>숙소 등록 완료하기</Typography>}
                {rstdata && rstdata.map((one) => {
                    return (<>
                        <Box border={'3px solid #d0d0d0'} borderRadius={"10px"} p={2} m={2} sx={[{ cursor: "pointer" }, { "&:hover": { borderColor: "black" } }]} onClick={(evt) => handleclick(one._id)} >
                            <Box sx={{ display: "flex", flexDirection: "row", justifyContent: "space-between", alignItems: "center" }} >
                                <Box sx={{ display: "flex", alignItems: "center" }}>
                                    <HomeIcon sx={{ bgcolor: "#ddd", p: "2px", borderRadius: 2, mr: 2, fontSize: 30 }} /><Typography fontSize={13.5}>{one.groupType}</Typography>
                                </Box>
                                <KeyboardArrowRightIcon />
                            </Box>
                        </Box>
                    </>)
                })}

                <Typography fontSize={20} fontWeight={"bold"} pl={2} mt={3}>숙소 등록 시작하기</Typography>

                <Box border={'3px solid #d0d0d0'} borderRadius={"10px"} p={2} m={2} sx={[{ cursor: "pointer" }, { "&:hover": { borderColor: "black" } }]} onClick={handleNew}>
                    <Box sx={{ display: "flex", flexDirection: "row", justifyContent: "space-between", alignItems: "center" }} >
                        <Box sx={{ display: "flex", alignItems: "center" }}>
                            <AddIcon sx={{ p: "2px", borderRadius: 2, mr: 2, fontSize: 30 }} /><Typography fontSize={13.5}>새로운 숙소 등록하기</Typography>
                        </Box>
                        <KeyboardArrowRightIcon />

                    </Box>
                </Box>
                <Link href={"/"}>
                    <Button>나가기</Button>
                </Link>
            </Grid>
        </Grid>

    );
}

BecomeAHostPropertyTypeGroup.isLayout = false