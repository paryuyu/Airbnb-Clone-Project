export default function Intro() {

    //시작하기 누르면 /become-a-host/property-type-group 로 가기

    return ( <h2>간단한 10단계로 호스팅 시작하기</h2> );
}



Intro.layout = "L2";