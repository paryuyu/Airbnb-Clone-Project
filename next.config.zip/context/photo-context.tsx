import { useState } from "react";
import { createContext } from "react";

type PhotoCtx = {
    files?:File[],
    addFiles?:(frag:File[]) => void;
    removeFile?: (t:File) => void;

}

export const PhotosContext = createContext({});

export function PhotosProvider({children}){
    const [files,setFiles] = useState<File[]>([]);
    const addFiles = (frag:File[])=>{
        setFiles((current)=>[...current, ...frag]);

    };

    const removeFile=(t:File)=>{
        setFiles((current)=>{
            return current.filter(one => one !== t)
        })
    }
    
return (

<PhotosContext.Provider value={{files, addFiles, removeFile}}>{children}</PhotosContext.Provider>
)

}

