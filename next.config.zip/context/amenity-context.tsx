import { useState , useReducer} from "react";
import { createContext } from "react";
import { AmenityData } from "../lib/model/accomodation";

type amenity = {


}


export const AmenitiesContext = createContext({});

export function AmenityProvider({ children }) {
   

    const [facilities, setFacilities] = useState([]);
    const [spFa, setSpFa] = useState([]);
    const [safty, setSafty] = useState([]);
    const [next, setNext] = useState('');
    const [itemId, setitemId] = useState('');
    console.log(itemId,'ctx')
    console.log(next,'ctx-next')

let amenity = {
    facilities:facilities,
    safty:safty,
    special:spFa
} as AmenityData

    return (

        <AmenitiesContext.Provider value={{ setFacilities, setSpFa, setSafty, facilities, spFa, safty,setNext,setitemId }}>
            {children}
        </AmenitiesContext.Provider>
    )

}

