import { useState } from "react";
import { createContext } from "react";



export const LocationCtx = createContext({});

export function LocationProvider({ children }) {
        
    type What = {lat:string, lng:string}
    const [location, setLocation] = useState<string>('');
    const [what, setWhat] = useState<What>() 
    console.log(what,'what')

    return (

        <LocationCtx.Provider value={{ location, setLocation,what, setWhat}}>

            {children}

        </LocationCtx.Provider>
    )

}

