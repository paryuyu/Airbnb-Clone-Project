export default function Footer () {
    return ( <p>푸터</p>);
}
