import { Wrapper } from "@googlemaps/react-wrapper";
import { Box } from "@mui/system";
import React from 'react'
import { LocationCtx } from "../../context/location-context";

function MapComponents({ }) {
    const [lat, setLat] = React.useState(null)
    const [lng, setLng] = React.useState(null)
    const ctx = React.useContext(LocationCtx);
    const ref = React.useRef<HTMLElement>();


    React.useEffect(() => {
        let lat: number;
        let lng: number;
    
        
        //지금 위치 
        if(!ctx?.what?.lat){
            navigator.geolocation.getCurrentPosition(function (pos) {
                ctx.setWhat({lat: pos.coords.latitude, lng: pos.coords.longitude})
            })
        }
    }, [])

    React.useEffect(() => {

        let map = new window.google.maps.Map(ref?.current, {
            center: { lat: ctx?.what?.lat, lng: ctx?.what?.lng },
            zoom: 15
        })

        const image = "/icons/marker.png";

        const marker = new google.maps.Marker({
            position: { lat, lng },
            map: map,
            icon: image,
        });

        map.addListener("center_changed", () => {
            
           
            setTimeout( ()=>{

            const center = map.getCenter();
            
            marker.setPosition({ lat: center?.lat()!, lng: center?.lng()! });
            // ctx?.setWhat({ lat: center?.lat(), lng: center?.lng() });
        },100)
        });
  
    }, [ctx])

    return (
        <Box ref={ref} sx={{ height: '100vh', width: '50vw' }}></Box>)
}




export const Maap = ({ }) => {

    let GoogleAppKey = "AIzaSyAXTs6QeXQ0EZ4B5pCOv93vnnCx0LwEKIs";
    return (
        <Wrapper apiKey={"AIzaSyAXTs6QeXQ0EZ4B5pCOv93vnnCx0LwEKIs"}>
            <MapComponents />
        </Wrapper>
    )
}